export default {
    STR_CNX : 'mongodb+srv://daniel:daniel123@misdatos.fs00f.mongodb.net/empresa?retryWrites=true&w=majority'
    //STR_CNX : 'mongodb://localhost/empresa'
}