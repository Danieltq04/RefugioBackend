import express from 'express'
import routerProductos from './router/productos.js'
import db from './model/db.js'

/* await  */db.conectar()

const app = express()
app.use(express.json())
app.use(express.urlencoded({extended: true}))

app.get('/ping', (req,res) => {
    res.send('pong')
})


app.use('/api/productos', routerProductos)


const PORT = process.env.PORT || 8080   //Short Circuit Operator
const server = app.listen(PORT, 
    () => console.log(`Servidor APIRestful escuchando en el puerto ${PORT}`)
)
server.on('error', err => console.log(`Error en servidor: ${err.message}`))
